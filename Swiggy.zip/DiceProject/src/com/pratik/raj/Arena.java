package com.pratik.raj;

public class Arena {
    private Player player1;
    private Player player2;

    // Constructor to initialize players
    public Arena(Player player1, Player player2) {
        this.player1 = player1;
        this.player2 = player2;
    }

    // Method to simulate the battle
    public void startBattle() {
        Player attacker = player1.getHealth() < player2.getHealth() ? player1 : player2;
        Player defender = attacker == player1 ? player2 : player1;

        while (!attacker.isDead() && !defender.isDead()) {
            // Attack phase: attacker rolls dice
            int attackDamage = attacker.getAttack() * (int)(Math.random() * 6 + 1);
            int defenseValue = defender.getStrength() * (int)(Math.random() * 6 + 1);
            int damage = Math.max(0, attackDamage - defenseValue);

            // Apply damage
            defender.takeDamage(damage);

            // Swap turns
            Player temp = attacker;
            attacker = defender;
            defender = temp;

            // Output current health status
            System.out.println("Player 1 health: " + player1.getHealth() + ", Player 2 health: " + player2.getHealth());
        }

        // Determine winner
        if (player1.isDead()) {
            System.out.println("Player 2 wins!");
        } else {
            System.out.println("Player 1 wins!");
        }
    }
}


