package com.pratik.raj;

// File: PlayerTest.java
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.*;

public class PlayerTest {

    @ParameterizedTest
    @CsvSource({
        "50, 5, 10, 40",
        "100, 10, 5, 90",
        "80, 8, 6, 75"
    })
    public void testPlayerDamage(int initialHealth, int strength, int attack, int expectedHealthAfterDamage) {
        // Arrange: create a player with specified attributes
        Player player = new Player(initialHealth, strength, attack);
        
        // Simulate a simple damage calculation
        player.takeDamage(10);

        // Assert: Check if health is correctly updated
        assertEquals(expectedHealthAfterDamage, player.getHealth());
    }
}


