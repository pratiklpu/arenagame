package com.pratik.raj;

//File: Player.java
public class Player {
    private int health;
    private int strength;
    private int attack;

    // Constructor to initialize player attributes
    public Player(int health, int strength, int attack) {
        this.health = health;
        this.strength = strength;
        this.attack = attack;
    }

    // Getter methods
    public int getHealth() { return health; }
    public int getStrength() { return strength; }
    public int getAttack() { return attack; }

    // Method to take damage
    public void takeDamage(int damage) {
        this.health -= damage;
    }

    // Check if player is dead
    public boolean isDead() {
        return this.health <= 0;
    }
}




