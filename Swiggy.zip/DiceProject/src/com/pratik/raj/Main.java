package com.pratik.raj;

//File: Main.java
public class Main {
    public static void main(String[] args) {
        // Test case 1
        Player player1 = new Player(50, 5, 10);
        Player player2 = new Player(100, 10, 5);
        Arena arena1 = new Arena(player1, player2);
        System.out.println("Test case 1:");
        arena1.startBattle();

        // Test case 2
        Player player3 = new Player(80, 8, 6);
        Player player4 = new Player(90, 6, 7);
        Arena arena2 = new Arena(player3, player4);
        System.out.println("Test case 2:");
        arena2.startBattle();
    }
}

