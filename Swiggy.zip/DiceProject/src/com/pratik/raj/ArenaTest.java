package com.pratik.raj;

//File: ArenaTest.java
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.*;

public class ArenaTest {

    @ParameterizedTest
    @CsvSource({
        "50, 5, 10, 100, 10, 5, 2",
        "80, 8, 6, 90, 6, 7, 1"
    })
    public void testArenaBattle(int health1, int strength1, int attack1, int health2, int strength2, int attack2, int expectedWinner) {
        // Arrange: create players and arena
        Player player1 = new Player(health1, strength1, attack1);
        Player player2 = new Player(health2, strength2, attack2);
        Arena arena = new Arena(player1, player2);
        
        // Act: Start battle
        arena.startBattle();
        
        // Assert: Determine the winner
        if (expectedWinner == 1) {
            assertTrue(player1.isDead() == false && player2.isDead() == true);
        } else {
            assertTrue(player1.isDead() == true && player2.isDead() == false);
        }
    }
}



